package com.example.flutter_taller_para_entregar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
