
import 'package:flutter/material.dart';
import '../widgets/section_card.dart';

class DatosPersonalesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Datos Personales'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SectionCard(
          title: 'Datos Personales',
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('• Nombre: Andres Rivera'),
              SizedBox(height: 10),
              Text('• Edad: 17 años'),
              SizedBox(height: 10),
              Text('• Dirección: El Tambo, Cauca, Colombia'),
              SizedBox(height: 10),
              Text('• Teléfono: +57 123 456 789'),
              SizedBox(height: 10),
              Text('• Email: andres_rivera@email.com'),
            ],
          ),
        ),
      ),
    );
  }
}
