// import 'package:flutter/material.dart';

// class ReferenciasScreen extends StatelessWidget {
//   final List<String> referencias = [
//     'Empresa ABC - Gerente: Ana López - ana.lopez@empresaabc.com',
//     'Empresa XYZ - Director: Carlos González - carlos.gonzalez@empresa.xyz',
//     'TECNICO EN MESA Y BAR - Director: Alberto Perez - alberto23@gmail.com',
//   ];

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Referencias Laborales'),
//       ),
//       body: ListView.builder(
//         itemCount: referencias.length,
//         itemBuilder: (context, index) {
//           return ListTile(
//             title: Text(referencias[index]),
//           );
//         },
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import '../widgets/section_card.dart';

class ReferenciasScreen extends StatelessWidget {
  final List<String> referencias = [
    'Empresa frisby - Gerente: Ana López - ana.lopez@empresafrisby.com',
    'Empresa YAMAHA - Director: Carlos González - carlos.gonzalez@empresa.yamaha',
    'Mineria - Chede: David Rodríguez - david.rodriguez@mineriachede.com',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Referencias Laborales'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SectionCard(
          title: 'Referencias Laborales',
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: referencias.map((ref) => Text('• $ref')).toList(),
          ),
        ),
      ),
    );
  }
}
