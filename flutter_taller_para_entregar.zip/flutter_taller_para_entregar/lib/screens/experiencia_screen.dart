
import 'package:flutter/material.dart';
import '../widgets/section_card.dart';

class ExperienciaScreen extends StatelessWidget {
  final List<String> experiencia = [
    'Desarrollador de sofware en Empresa ESTADO-UNIDENSE (2018-2020)',
    'Desarrollador Full Stack en Empresa COLOMBIANA (2020-2022)',
    'especializado en Flutter SENA (2023-presente)',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Experiencia Laboral'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SectionCard(
          title: 'Experiencia Laboral',
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: experiencia.map((exp) => Text('• $exp')).toList(),
          ),
        ),
      ),
    );
  }
}
