import 'package:flutter/material.dart';
import '../widgets/section_card.dart';

class EstudiosScreen extends StatelessWidget {
  final List<String> estudios = [
    'Ingeniería en Sistemas - Universidad AUTONOMA',
    'Curso de Flutter Avanzado - EN EL INEM',
    'Certificación en Arquitectura de Software - Platzi',
    'Certificacion en Mesa y Bar - Sena'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Estudios'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SectionCard(
          title: 'Estudios y Certificaciones',
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: estudios.map((est) => Text('• $est')).toList(),
          ),
        ),
      ),
    );
  }
}
